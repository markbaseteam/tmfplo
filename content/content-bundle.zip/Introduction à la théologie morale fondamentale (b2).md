---
home: true
---

# Etat des lieux

De nombreuses études. Selon cette source, les bombardements ont «_gravement endommagé_» une station renfermant de l'azote et de l'oxygène et un «_bâtiment auxiliaire_». «_Il existe toujours des risques de fuite d'hydrogène et de substances radioactives, et le risque d'incendie est également élevé_», a-t-elle dit.

«_Le bombardement (...) a causé un risque sérieux pour le fonctionnement en toute sécurité de la centrale_», a poursuivi Energoatom, indiquant toutefois qu'elle continue de produire de l'électricité et que le personnel ukrainien continue d'y travailler.

## 1980
C'est difficile. Voir les dernières photos:

![[Pasted image 20220806234522.png]]

## 1995
C'est pire.
Et voilà. Un *effort* énorme a été fait mais sans **succès**. Nous verrons plus tard.
Blablabla. On peut avoir plus d'informations par ici: www.google.com

### Somme théologique
La liste est longue:
- bla bla bla
- et puis blabla bla
- enfin, blablabla

On peut trouver cela bizarre. Comme dit St Thomas:
> Quid quid recipitur ad modum....

>[!warning] C'est dangereux 
> A lire encore





